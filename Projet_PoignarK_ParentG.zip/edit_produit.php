<?php
  $page_title = 'Editer produit';
  require_once('includes/load.php');
  // Verification du niveau d'autorisation
   page_require_level(2);
?>
<?php
$produit = find_by_id('produit',(int)$_GET['id']);
$all_categories = find_all('categories');
if(!$produit){
  $session->msg("d","ID Produit Manquant.");
  redirect('produit.php');
}
?>
<?php
 if(isset($_POST['produit'])){
    $req_fields = array('produit-title','produit-categorie','produit-quantity');
    validate_fields($req_fields);

   if(empty($errors)){
       $p_name  = remove_junk($db->escape($_POST['produit-title']));
       $p_cat   = (int)$_POST['produit-categorie'];
       $p_qty   = remove_junk($db->escape($_POST['produit-quantity']));
       $query   = "UPDATE produit SET";
       $query  .=" name ='{$p_name}', quantity ='{$p_qty}',";
       $query  .="categorie_id ='{$p_cat}'";
       $query  .=" WHERE id ='{$produit['id']}'";
       $result = $db->query($query);
               if($result && $db->affected_rows() === 1){
                 $session->msg('s',"produit mis à jour ");
                 redirect('produit.php', false);
               } else {
                 $session->msg('d',' Échec mise à jour produit!');
                 redirect('edit_produit.php?id='.$produit['id'], false);
               }

   } else{
       $session->msg("d", "Information Incorrecte ou Vide");
       redirect('edit_produit.php?id='.$produit['id'], false);
   }

 }

?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
  </div>
</div>
  <div class="row">
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong>
            <span class="glyphicon glyphicon-th"></span>
            <span>Mise à jour produit</span>
         </strong>
        </div>
        <div class="panel-body">
         <div class="col-md-7">
           <form method="post" action="edit_produit.php?id=<?php echo (int)$produit['id'] ?>">
              <div class="form-group">
                <div class="input-group">
                  <span class="input-group-addon">
                   <i class="glyphicon glyphicon-th-large"></i>
                  </span>
                  <input type="text" class="form-control" name="produit-title" value="<?php echo remove_junk($produit['name']);?>">
               </div>
              </div>
              <div class="form-group">
                <div class="row">
                  <div class="col-md-6">
                    <select class="form-control" name="produit-categorie">
                    <option value=""> Selectionner une categorie</option>
                   <?php  foreach ($all_categories as $cat): ?>
                     <option value="<?php echo (int)$cat['id']; ?>" <?php if($produit['categorie_id'] === $cat['id']): echo "selected"; endif; ?> >
                       <?php echo remove_junk($cat['name']); ?></option>
                   <?php endforeach; ?>
                 </select>
                  </div>
                </div>
              </div>

              <div class="form-group">
               <div class="row">
                 <div class="col-md-4">
                  <div class="form-group">
                    <label for="qty">Quantité</label>
                    <div class="input-group">
                      <span class="input-group-addon">
                       <i class="glyphicon glyphicon-shopping-cart"></i>
                      </span>
                      <input type="number" class="form-control" name="produit-quantity" value="<?php echo remove_junk($produit['quantity']); ?>">
                   </div>
                  </div>
                 </div>
               </div>
              </div>
              <button type="submit" name="produit" class="btn btn-danger">Mise à jour</button>
          </form>
         </div>
        </div>
      </div>
  </div>

<?php include_once('layouts/menu.php'); ?>
