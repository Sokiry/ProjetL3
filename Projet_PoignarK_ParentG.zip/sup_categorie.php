<?php
  require_once('includes/load.php');
  //Verification du niveau d'autorisation
  page_require_level(2);
?>
<?php
  $categorie = find_by_id('categories',(int)$_GET['id']);
  if(!$categorie){
    $session->msg("d","ID Categorie manquant.");
    redirect('categorie.php');
  }
?>
<?php
  $sup_id = sup_by_id('categories',(int)$categorie['id']);
  if($sup_id){
      $session->msg("s","Categorie supprimée avec succès.");
      redirect('categorie.php');
  } else {
      $session->msg("d","Échec de la suppression.");
      redirect('categorie.php');
  }
?>
