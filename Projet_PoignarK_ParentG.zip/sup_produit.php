<?php
  require_once('includes/load.php');
  // Verification du niveau d'autorisation
  page_require_level(2);
?>
<?php
  $produit = find_by_id('produit',(int)$_GET['id']);
  if(!$produit){
    $session->msg("d","ID Produit Manquant.");
    redirect('produit.php');
  }
?>
<?php
  $sup_id = sup_by_id('produit',(int)$produit['id']);
  if($sup_id){
      $session->msg("s","Produits Supprimé.");
      redirect('produit.php');
  } else {
      $session->msg("d","Échec de la suppression.");
      redirect('produit.php');
  }
?>
