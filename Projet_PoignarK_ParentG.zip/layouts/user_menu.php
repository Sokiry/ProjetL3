<ul>
  <li>
    <a href="admin.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Tableau de bord</span>
    </a>
  </li>
  <li>
    <a href="categorie.php" >
      <i class="glyphicon glyphicon-indent-left"></i>
      <span>Categories</span>
    </a>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-large"></i>
      <span>Produits</span>
    </a>
    <ul class="nav submenu">
       <li><a href="produit.php">Gestion Produits</a> </li>
       <li><a href="add_produit.php">Ajouter Produit</a> </li>
   </ul>
  </li>
</ul>
