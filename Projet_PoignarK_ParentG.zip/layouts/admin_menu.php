<ul>
  <li>
    <a href="admin.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Tableau de bord</span>
    </a>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-user"></i>
      <span>Gestion Utilisateur</span>
    </a>
    <ul class="nav submenu">
      <li><a href="group.php">Gestion Groupe</a> </li>
      <li><a href="users.php">Gestion Utilisateur</a> </li>
   </ul>
  </li>
  <li>
    <a href="categorie.php" >
      <i class="glyphicon glyphicon-indent-left"></i>
      <span>Categories</span>
    </a>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-large"></i>
      <span>Produits</span>
    </a>
    <ul class="nav submenu">
       <li><a href="produit.php">Gestion Produits</a> </li>
       <li><a href="add_produit.php">Ajouter Produit</a> </li>
   </ul>
  </li>
</ul>