<?php
  $page_title = 'Les Produits';
  require_once('includes/load.php');
  // Verification du niveau d'autorisation
   page_require_level(2);
  $produit = join_produit_table();
?>
<?php include_once('layouts/header.php'); ?>
  <div class="row">
     <div class="col-md-12">
       <?php echo display_msg($msg); ?>
     </div>
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading clearfix">
         <div class="pull-right">
           <a href="add_produit.php" class="btn btn-primary">Ajouter Produit</a>
         </div>
        </div>
        <div class="panel-body">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th class="text-center" style="width: 5%;">#</th>
                <th class="text-center" style="width: 15%;"> Nom Produit </th>
                <th class="text-center" style="width: 15%;"> Categories </th>
                <th class="text-center" style="width: 15%;"> Stock </th>
                <th class="text-center" style="width: 15%;"> Date d'ajout </th>
                <th class="text-center" style="width: 15%;"> Actions </th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($produit as $produit):?>
              <tr>
                <td class="text-center"><?php echo count_id();?></td>
                <td> <?php echo remove_junk($produit['name']); ?></td>
                <td class="text-center"> <?php echo remove_junk($produit['categorie']); ?></td>
                <td class="text-center"> <?php echo remove_junk($produit['quantity']); ?></td>
                <td class="text-center"> <?php echo read_date($produit['date']); ?></td>
                <td class="text-center">
                  <div class="btn-group">
                    <a href="edit_produit.php?id=<?php echo (int)$produit['id'];?>" class="btn btn-info btn-xs"  title="Editer" data-toggle="tooltip">
                      <span class="glyphicon glyphicon-edit"></span>
                    </a>
                    <a href="sup_produit.php?id=<?php echo (int)$produit['id'];?>" class="btn btn-danger btn-xs"  title="Supprimer" data-toggle="tooltip">
                      <span class="glyphicon glyphicon-trash"></span>
                    </a>
                  </div>
                </td>
              </tr>
             <?php endforeach; ?>
            </tbody>
          </tabel>
        </div>
      </div>
    </div>
  </div>
  <?php include_once('layouts/menu.php'); ?>
